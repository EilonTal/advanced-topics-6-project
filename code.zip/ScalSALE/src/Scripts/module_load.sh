#!/bin/bash 
module purge
module load gnu/9.1.0 openmpi/4.1.3-gnu cmake
module load intel/18.0.1.163 openmpi/4.0.4_intel cmake ScientificLibraries/silo/4.11-intel
module load anaconda2
